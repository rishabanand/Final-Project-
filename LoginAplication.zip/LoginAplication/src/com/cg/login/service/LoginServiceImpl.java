package com.cg.login.service;

import java.util.List;

import com.cg.login.dao.LoginDao;
import com.cg.login.dao.LoginDaoImpl;
import com.cg.login.exception.LoginException;
import com.cg.login.dto.Login;

public class LoginServiceImpl implements LoginService{

	LoginDao loginDao=new LoginDaoImpl();	

	@Override
	public boolean validateUser(String username, String password) throws LoginException {
		
		List<Login> userDetailsList=loginDao.getAllUsers();
		for(Login tempUserList : userDetailsList)
		{
			if(username.equals(tempUserList.getUserName()) 
					&& password.equals(tempUserList.getPassword()))
			{
				return true;
			}
		}
		return false;
	}
	

}
