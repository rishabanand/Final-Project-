package com.cg.login.service;

import com.cg.login.exception.LoginException;

public interface LoginService {
	public boolean validateUser(String username, String password) throws LoginException;
}
