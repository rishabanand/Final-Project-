package com.cg.login.dao;

import java.util.List;

import com.cg.login.exception.LoginException;
import com.cg.login.dto.Login;
;

public interface LoginDao 
{
	public List<Login> getAllUsers() throws LoginException;
	
	
}
