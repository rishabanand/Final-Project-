package com.cg.login.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.login.dto.Login;
import com.cg.login.exception.LoginException;
import com.cg.user.util.DbUtil;


public class LoginDaoImpl implements LoginDao
{
	Connection conn=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	@Override
	public List<Login> getAllUsers() throws LoginException {
		List<Login> userList=new ArrayList<>();
		conn=DbUtil.getConn();
		Statement st;
		try 
		{
			st = conn.createStatement();
			ResultSet rs=st.executeQuery("SELECT * from UserDetails");
			while(rs.next())
			{
				Login login=new Login();
				login.setUserName(rs.getString("username"));
				login.setPassword(rs.getString("password"));
				userList.add(login);
			}
		}
		catch (SQLException e) 
		{			
			throw new LoginException("Problem in fetching mobileList"+e.getMessage());
		}
		return userList;
	}

	
}
