package com.cg.user.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.login.exception.LoginException;



public class DbUtil 
{
	public static Connection getConn() throws LoginException
	{
		Connection con=null;
		InitialContext context;
		if(con==null)
		{
			try 
			{
				context=new InitialContext();
				DataSource ds=(DataSource)context.lookup("java/jdbc/OracleDS");
				con=ds.getConnection();
			} 
			catch (NamingException e) 
			{
				throw new LoginException("Problem in obtaining DataSource "+e.getMessage());
			}
			catch (SQLException e) 
			{
				throw new LoginException("Problem in obtaining Connection"+e.getMessage());
			}
		}
		return con;
		
			/*Connection con=null;
			try {
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			return con;*/
		
	}
	
	
}
